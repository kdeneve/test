﻿namespace DienstenCheques.Models.Domain
{
    public enum PrestatieType
    {
        Schoonmaken,
        WassenEnStrijken,
        BereidenMaaltijden
    }
}
