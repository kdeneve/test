﻿namespace DienstenCheques.Models.Domain
{
    public class Onderneming
    {
        #region "Properties"

        public int OndernemingId { get; set; }
        public string Naam { get; set; }

        #endregion

    }
}
